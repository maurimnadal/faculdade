from cpu import CPU

escalonador = CPU(quantum=3)
escalonador.adicionar_processo("P1", 10)
escalonador.adicionar_processo("P2", 4)
escalonador.adicionar_processo("P3", 7)

escalonador.executar()