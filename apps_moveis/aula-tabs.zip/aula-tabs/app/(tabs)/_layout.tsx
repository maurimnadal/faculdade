import { Tabs } from "expo-router";


export default function TabsLayout(){
    return (
        <Tabs>
            <Tabs.Screen name ="home"
            options={{title: "Inicial"}}/>
            <Tabs.Screen name="profile"
            options={{title: "Perfil"}}/>
        </Tabs>
    )
}